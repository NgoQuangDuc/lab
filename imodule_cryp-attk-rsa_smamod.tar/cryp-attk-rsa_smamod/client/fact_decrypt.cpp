#include <iostream>
using namespace std;

int main() {
    cout << "Hãy viết giải thuật thám mã trên số n nhỏ trên RSA" << endl;
    return 0;
}

