#!/usr/bin/env bash

sudo /etc/init.d/xinetd restart
