#include <iostream>
#include <cmath>
#include <cstdlib>

using namespace std;

// Hàm tính bản mã c = m^e
unsigned long long encrypt(unsigned long long m, unsigned long long e) {
    return pow(m, e);
}

// Hàm giải mã, tính m = c^(1/e)
unsigned long long decrypt(unsigned long long c, unsigned long long e) {
    return round(pow(c, 1.0 / e));
}

int main() {
    // Số nguyên tố p và q (ví dụ cho đơn giản)
    unsigned long long p = 11, q = 17;
    
    // Tính n = p * q
    unsigned long long n = p * q;

    // Chọn e = 3
    unsigned long long e = 3;

    // Tin nhắn m (m nhỏ)
    unsigned long long m;
    cout << "Nhap tin nhan m (m < n): ";
    cin >> m;

    // Kiểm tra điều kiện m < n
    if (m >= n) {
        cout << "Tin nhan m phai be hon n!" << endl;
        return -1;
    }

    // Mã hóa tin nhắn
    unsigned long long c = encrypt(m, e);
    cout << "Ban ma (c) = m^e = " << c << endl;

    // Giải mã tin nhắn
    unsigned long long decrypted_m = decrypt(c, e);
    cout << "Ban ro (m) sau khi giai ma: " << decrypted_m << endl;

    return 0;
}

